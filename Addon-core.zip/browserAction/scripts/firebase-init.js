var firebaseConfig = {
    apiKey: "AIzaSyAqsMU9JXMziQ-En7vrbNRqr5y_6J6fZ5A",
    authDomain: "nitktoastmasters-da7c7.firebaseapp.com",
    databaseURL: "https://nitktoastmasters-da7c7.firebaseio.com",
    projectId: "nitktoastmasters-da7c7",
    storageBucket: "nitktoastmasters-da7c7.appspot.com",
    messagingSenderId: "336393535782"
};
firebase.initializeApp(firebaseConfig);