To test:
Open the debugging page of Firefox Add=ons (Settings -> Add-ons -> Click Key-cog dropdown -> Debug Add-ons).
Then, zip the files in this directory to a zip file named `Addon-core.zip`.
Upload the zip file as a Temporary Add-on.