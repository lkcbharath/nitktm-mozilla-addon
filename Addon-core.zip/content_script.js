// Put all the javascript code here, that you want to execute after page load.
// document.body.style.border = "5px solid red";